function z0=spec_init(A,y)

% This code is adapted from "Solving Quadratic Systems of Equations via
% Truncated Wirtinger Flow" by Yuxin Chen and Emmanuel J. Cand�s.
% (http://www.princeton.edu/~yc5/TWF/code.html)

%See also  
%	Fundamental Limits of Weak Recovery with Applications to Phase Retrieval
%	https://arxiv.org/abs/1708.05932 
%for an alternative initialization scheme 

[m,n]=size(A);
npower_iter = 50;           % Number of power iterations 
alpha=3;
z0 = randn(n,1); z0 = z0/norm(z0);    % Initial guess 
normest = sqrt(sum(y))/m;    % Estimate norm to scale eigenvector  
    
for tt = 1:npower_iter,                     % Truncated power iterations
    ytr = y.* (abs(y) <=  alpha^2 * normest^2 );
    z0 = A'*( ytr.* (A*z0) ); z0 = z0/norm(z0);
end
    
z = normest * z0;                   % Apply scaling
