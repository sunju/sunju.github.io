%Codes implementing the block coordinate descent (BCD) method analyzed in the paper 
%	 A Local Analysis of Block Coordinate Descent for Gaussian Phase Retrieval
%	 https://arxiv.org/abs/1712.02083 
% Pls send comments or bug reports to 
%	David Barmherzig (davidbar@stanford.edu) or Ju Sun (sunju@stanford.edu)
% Version: 03/26/2018 

clear; 
rng(1)
%% Problem data
n=500;
m=8*n;
A=randn(m,n);
x=randn(n,1);
x=x./norm(x);    % assume x is normalized
ysq=abs(A*x).^2;

%% Set algorithm parameters
iter_max = 1e3;
dist_tol = 1e-6;  
rho = 1;         % ideally on the order C||x||^2 for C not too large
%% Initialization
z_k=spec_init(A,ysq);
w_k=z_k;

% Error metric 
dist_err = @(w) min(norm(x-w)/norm(x),norm(x+w)/norm(x)); 

iter = 1; 
%% Algorithm Run

while iter <= iter_max && dist_err(w_k) >= dist_tol
    z_k=L_min(ysq,A,w_k,rho);
    w_k=L_min(ysq,A,z_k,rho);
    disp(['iter = ', num2str(iter), ', error = ', num2str(dist_err(w_k))]); 
    iter = iter + 1; 
end
