%Finds the minimizer of the subproblem 

function x=L_min(b,M,z,rho);
[m,n]=size(M);
A=[sqrt(0.5/m)*bsxfun(@times,M,M*z); sqrt(rho)*eye(n)];
bb=[sqrt(0.5/m)*b; sqrt(rho)*z];
x = (A'*A)\(A'*bb); 

